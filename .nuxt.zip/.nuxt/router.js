import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _aae8ba4c = () => interopDefault(import('..\\pages\\collect\\index.vue' /* webpackChunkName: "pages/collect/index" */))
const _ebdc8da0 = () => interopDefault(import('..\\pages\\history\\index.vue' /* webpackChunkName: "pages/history/index" */))
const _311eb9a8 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _af8ac92c = () => interopDefault(import('..\\pages\\tag\\index.vue' /* webpackChunkName: "pages/tag/index" */))
const _ca66a456 = () => interopDefault(import('..\\pages\\up\\index.vue' /* webpackChunkName: "pages/up/index" */))
const _51b59db6 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _b28b1692 = () => interopDefault(import('..\\pages\\search\\result.vue' /* webpackChunkName: "pages/search/result" */))
const _78d70ea0 = () => interopDefault(import('..\\pages\\user\\pwdChange.vue' /* webpackChunkName: "pages/user/pwdChange" */))
const _349626da = () => interopDefault(import('..\\pages\\user\\pwdForgot.vue' /* webpackChunkName: "pages/user/pwdForgot" */))
const _8c60567c = () => interopDefault(import('..\\pages\\user\\pwdset.vue' /* webpackChunkName: "pages/user/pwdset" */))
const _14d15a72 = () => interopDefault(import('..\\pages\\user\\sendEmail.vue' /* webpackChunkName: "pages/user/sendEmail" */))
const _3fea1b8e = () => interopDefault(import('..\\pages\\user\\setMyitbo.vue' /* webpackChunkName: "pages/user/setMyitbo" */))
const _75c5da20 = () => interopDefault(import('..\\pages\\user\\setName.vue' /* webpackChunkName: "pages/user/setName" */))
const _1fcb3edc = () => interopDefault(import('..\\pages\\video\\video.vue' /* webpackChunkName: "pages/video/video" */))
const _6f1399d0 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _4e62ba11 = () => interopDefault(import('..\\pages\\video\\_id.vue' /* webpackChunkName: "pages/video/_id" */))
const _c6ac21c8 = () => interopDefault(import('..\\pages\\type\\_id\\_name.vue' /* webpackChunkName: "pages/type/_id/_name" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/collect",
    component: _aae8ba4c,
    name: "collect"
  }, {
    path: "/history",
    component: _ebdc8da0,
    name: "history"
  }, {
    path: "/search",
    component: _311eb9a8,
    name: "search"
  }, {
    path: "/tag",
    component: _af8ac92c,
    name: "tag"
  }, {
    path: "/up",
    component: _ca66a456,
    name: "up"
  }, {
    path: "/user",
    component: _51b59db6,
    name: "user"
  }, {
    path: "/search/result",
    component: _b28b1692,
    name: "search-result"
  }, {
    path: "/user/pwdChange",
    component: _78d70ea0,
    name: "user-pwdChange"
  }, {
    path: "/user/pwdForgot",
    component: _349626da,
    name: "user-pwdForgot"
  }, {
    path: "/user/pwdset",
    component: _8c60567c,
    name: "user-pwdset"
  }, {
    path: "/user/sendEmail",
    component: _14d15a72,
    name: "user-sendEmail"
  }, {
    path: "/user/setMyitbo",
    component: _3fea1b8e,
    name: "user-setMyitbo"
  }, {
    path: "/user/setName",
    component: _75c5da20,
    name: "user-setName"
  }, {
    path: "/video/video",
    component: _1fcb3edc,
    name: "video-video"
  }, {
    path: "/",
    component: _6f1399d0,
    name: "index"
  }, {
    path: "/video/:id?",
    component: _4e62ba11,
    name: "video-id"
  }, {
    path: "/type/:id?/:name?",
    component: _c6ac21c8,
    name: "type-id-name"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
