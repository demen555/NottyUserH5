import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6f1399d0 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _aae8ba4c = () => interopDefault(import('..\\pages\\collect\\index.vue' /* webpackChunkName: "pages/collect/index" */))
const _ebdc8da0 = () => interopDefault(import('..\\pages\\history\\index.vue' /* webpackChunkName: "pages/history/index" */))
const _42ee23d1 = () => interopDefault(import('..\\pages\\home.vue' /* webpackChunkName: "pages/home" */))
const _311eb9a8 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _af8ac92c = () => interopDefault(import('..\\pages\\tag\\index.vue' /* webpackChunkName: "pages/tag/index" */))
const _ca66a456 = () => interopDefault(import('..\\pages\\up\\index.vue' /* webpackChunkName: "pages/up/index" */))
const _51b59db6 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _b28b1692 = () => interopDefault(import('..\\pages\\search\\result.vue' /* webpackChunkName: "pages/search/result" */))
const _78d70ea0 = () => interopDefault(import('..\\pages\\user\\pwdChange.vue' /* webpackChunkName: "pages/user/pwdChange" */))
const _349626da = () => interopDefault(import('..\\pages\\user\\pwdForgot.vue' /* webpackChunkName: "pages/user/pwdForgot" */))
const _8c60567c = () => interopDefault(import('..\\pages\\user\\pwdset.vue' /* webpackChunkName: "pages/user/pwdset" */))
const _14d15a72 = () => interopDefault(import('..\\pages\\user\\sendEmail.vue' /* webpackChunkName: "pages/user/sendEmail" */))
const _3fea1b8e = () => interopDefault(import('..\\pages\\user\\setMyitbo.vue' /* webpackChunkName: "pages/user/setMyitbo" */))
const _75c5da20 = () => interopDefault(import('..\\pages\\user\\setName.vue' /* webpackChunkName: "pages/user/setName" */))
const _1fcb3edc = () => interopDefault(import('..\\pages\\video\\video.vue' /* webpackChunkName: "pages/video/video" */))
const _4b769a02 = () => interopDefault(import('..\\pages\\tag\\_name.vue' /* webpackChunkName: "pages/tag/_name" */))
const _4e62ba11 = () => interopDefault(import('..\\pages\\video\\_id.vue' /* webpackChunkName: "pages/video/_id" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/en",
    component: _6f1399d0,
    name: "index___en"
  }, {
    path: "/pt",
    component: _6f1399d0,
    name: "index___pt"
  }, {
    path: "/en/collect",
    component: _aae8ba4c,
    name: "collect___en"
  }, {
    path: "/en/history",
    component: _ebdc8da0,
    name: "history___en"
  }, {
    path: "/en/home",
    component: _42ee23d1,
    name: "home___en"
  }, {
    path: "/en/search",
    component: _311eb9a8,
    name: "search___en"
  }, {
    path: "/en/tag",
    component: _af8ac92c,
    name: "tag___en"
  }, {
    path: "/en/up",
    component: _ca66a456,
    name: "up___en"
  }, {
    path: "/en/user",
    component: _51b59db6,
    name: "user___en"
  }, {
    path: "/pt/collect",
    component: _aae8ba4c,
    name: "collect___pt"
  }, {
    path: "/pt/history",
    component: _ebdc8da0,
    name: "history___pt"
  }, {
    path: "/pt/home",
    component: _42ee23d1,
    name: "home___pt"
  }, {
    path: "/pt/search",
    component: _311eb9a8,
    name: "search___pt"
  }, {
    path: "/pt/tag",
    component: _af8ac92c,
    name: "tag___pt"
  }, {
    path: "/pt/up",
    component: _ca66a456,
    name: "up___pt"
  }, {
    path: "/pt/user",
    component: _51b59db6,
    name: "user___pt"
  }, {
    path: "/en/search/result",
    component: _b28b1692,
    name: "search-result___en"
  }, {
    path: "/en/user/pwdChange",
    component: _78d70ea0,
    name: "user-pwdChange___en"
  }, {
    path: "/en/user/pwdForgot",
    component: _349626da,
    name: "user-pwdForgot___en"
  }, {
    path: "/en/user/pwdset",
    component: _8c60567c,
    name: "user-pwdset___en"
  }, {
    path: "/en/user/sendEmail",
    component: _14d15a72,
    name: "user-sendEmail___en"
  }, {
    path: "/en/user/setMyitbo",
    component: _3fea1b8e,
    name: "user-setMyitbo___en"
  }, {
    path: "/en/user/setName",
    component: _75c5da20,
    name: "user-setName___en"
  }, {
    path: "/en/video/video",
    component: _1fcb3edc,
    name: "video-video___en"
  }, {
    path: "/pt/search/result",
    component: _b28b1692,
    name: "search-result___pt"
  }, {
    path: "/pt/user/pwdChange",
    component: _78d70ea0,
    name: "user-pwdChange___pt"
  }, {
    path: "/pt/user/pwdForgot",
    component: _349626da,
    name: "user-pwdForgot___pt"
  }, {
    path: "/pt/user/pwdset",
    component: _8c60567c,
    name: "user-pwdset___pt"
  }, {
    path: "/pt/user/sendEmail",
    component: _14d15a72,
    name: "user-sendEmail___pt"
  }, {
    path: "/pt/user/setMyitbo",
    component: _3fea1b8e,
    name: "user-setMyitbo___pt"
  }, {
    path: "/pt/user/setName",
    component: _75c5da20,
    name: "user-setName___pt"
  }, {
    path: "/pt/video/video",
    component: _1fcb3edc,
    name: "video-video___pt"
  }, {
    path: "/en/tag/:name",
    component: _4b769a02,
    name: "tag-name___en"
  }, {
    path: "/en/video/:id?",
    component: _4e62ba11,
    name: "video-id___en"
  }, {
    path: "/pt/tag/:name",
    component: _4b769a02,
    name: "tag-name___pt"
  }, {
    path: "/pt/video/:id?",
    component: _4e62ba11,
    name: "video-id___pt"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
