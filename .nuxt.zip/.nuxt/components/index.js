export const Loading = () => import('../..\\components\\Loading.vue' /* webpackChunkName: "components/loading" */).then(c => wrapFunctional(c.default || c))
export const Cover = () => import('../..\\components\\cover\\index.vue' /* webpackChunkName: "components/cover" */).then(c => wrapFunctional(c.default || c))
export const Empty = () => import('../..\\components\\empty\\index.vue' /* webpackChunkName: "components/empty" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../..\\components\\footer\\index.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const DialogGuild = () => import('../..\\components\\dialog\\dialog-guild.vue' /* webpackChunkName: "components/dialog-guild" */).then(c => wrapFunctional(c.default || c))
export const DialogLine = () => import('../..\\components\\dialog\\dialog-line.vue' /* webpackChunkName: "components/dialog-line" */).then(c => wrapFunctional(c.default || c))
export const DialogLink = () => import('../..\\components\\dialog\\dialog-link.vue' /* webpackChunkName: "components/dialog-link" */).then(c => wrapFunctional(c.default || c))
export const DialogLogin = () => import('../..\\components\\dialog\\dialog-login.vue' /* webpackChunkName: "components/dialog-login" */).then(c => wrapFunctional(c.default || c))
export const DialogRegister = () => import('../..\\components\\dialog\\dialog-register.vue' /* webpackChunkName: "components/dialog-register" */).then(c => wrapFunctional(c.default || c))
export const HeaderTop = () => import('../..\\components\\header\\top.vue' /* webpackChunkName: "components/header-top" */).then(c => wrapFunctional(c.default || c))
export const Nav = () => import('../..\\components\\nav\\index.vue' /* webpackChunkName: "components/nav" */).then(c => wrapFunctional(c.default || c))
export const Overlay = () => import('../..\\components\\overlay\\index.vue' /* webpackChunkName: "components/overlay" */).then(c => wrapFunctional(c.default || c))
export const SkeletonCardLoad = () => import('../..\\components\\skeleton\\cardLoad.vue' /* webpackChunkName: "components/skeleton-card-load" */).then(c => wrapFunctional(c.default || c))
export const SkeletonTagLoad = () => import('../..\\components\\skeleton\\tagLoad.vue' /* webpackChunkName: "components/skeleton-tag-load" */).then(c => wrapFunctional(c.default || c))
export const SkeletonVideoLoad = () => import('../..\\components\\skeleton\\videoLoad.vue' /* webpackChunkName: "components/skeleton-video-load" */).then(c => wrapFunctional(c.default || c))
export const Test = () => import('../..\\components\\test\\index.vue' /* webpackChunkName: "components/test" */).then(c => wrapFunctional(c.default || c))
export const Thumb = () => import('../..\\components\\thumb\\index.vue' /* webpackChunkName: "components/thumb" */).then(c => wrapFunctional(c.default || c))
export const VideoM3u8 = () => import('../..\\components\\videoM3u8\\index.vue' /* webpackChunkName: "components/video-m3u8" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
