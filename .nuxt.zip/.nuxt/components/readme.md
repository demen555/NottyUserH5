# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Loading>` | `<loading>` (components/Loading.vue)
- `<Footer>` | `<footer>` (components/footer/index.vue)
- `<Cover>` | `<cover>` (components/cover/index.vue)
- `<DialogGuild>` | `<dialog-guild>` (components/dialog/dialog-guild.vue)
- `<DialogLine>` | `<dialog-line>` (components/dialog/dialog-line.vue)
- `<DialogLink>` | `<dialog-link>` (components/dialog/dialog-link.vue)
- `<DialogLogin>` | `<dialog-login>` (components/dialog/dialog-login.vue)
- `<DialogRegister>` | `<dialog-register>` (components/dialog/dialog-register.vue)
- `<Empty>` | `<empty>` (components/empty/index.vue)
- `<HeaderTop>` | `<header-top>` (components/header/top.vue)
- `<Nav>` | `<nav>` (components/nav/index.vue)
- `<Overlay>` | `<overlay>` (components/overlay/index.vue)
- `<Pagination>` | `<pagination>` (components/pagination/index.vue)
- `<SkeletonCardLoad>` | `<skeleton-card-load>` (components/skeleton/cardLoad.vue)
- `<SkeletonTagLoad>` | `<skeleton-tag-load>` (components/skeleton/tagLoad.vue)
- `<SkeletonVideoLoad>` | `<skeleton-video-load>` (components/skeleton/videoLoad.vue)
- `<Test>` | `<test>` (components/test/index.vue)
- `<Thumb>` | `<thumb>` (components/thumb/index.vue)
- `<VideoM3u8>` | `<video-m3u8>` (components/videoM3u8/index.vue)
- `<VideoMp4>` | `<video-mp4>` (components/videoMp4/index.vue)
- `<Vote>` | `<vote>` (components/vote/index.vue)
